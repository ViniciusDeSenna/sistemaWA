<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Illuminate\Validation\Rule;

class UsersController extends Controller
{
    public function index(){
        return View('app.users.index', ['users' => User::getActive()]);
    }

    public function create(){
        return View('app.users.edit', ['permissions' => Permission::all()]);
    }

    
    public function store(Request $request)
    {
        try {
            DB::beginTransaction();

            $validator = Validator::make($request->all(), [
                'name' => ['required', 'string', 'max:255'],
                'email' => [
                    'required', 
                    'string', 
                    'lowercase', 
                    'email', 
                    'max:255', 
                    Rule::unique(User::class)->where('active', true),
                ],
                'password' => ['required', 'confirmed', Rules\Password::defaults()],
            ]);            
        
            if ($validator->fails()) {
                return response()->json([
                    'message' => implode("\n", $validator->errors()->all()),
                ], 422);
            }
        
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);

            event(new Registered($user));
        
            // Seta as pemissoes no usuário
            $user->givePermissionTo(array_keys($request->permissions));

            DB::commit();

            return response()->json([
                'title' => 'Sucesso!',
                'message' => 'Usuário cadastrado com sucesso!',
                'type' => 'success'
            ], 201);

        } catch(Exception $exception) {

            DB::rollBack();

            return response()->json([
                'title' => 'Erro na validação',
                'message' => $exception->getMessage(),
                'type' => 'error'
            ], 500);
        }
    }
    

    public function edit($id){
        return View('app.users.edit', ['user' => User::find($id), 'permissions' => Permission::all()]);
    }

    public function update(Request $request, $id){
        try {
            DB::beginTransaction();

            $validator = Validator::make($request->all(), [
                'name' => ['required', 'string', 'max:255'],
                'email' => [
                    'required', 
                    'string', 
                    'lowercase', 
                    'email', 
                    'max:255', 
                    Rule::unique(User::class)->where('active', '=', true)->where('id', '!=', $id),
                ],
                'password' => ['nullable', 'confirmed', Rules\Password::defaults()],
            ]);            
        
            if ($validator->fails()) {
                return response()->json([
                    'message' => implode("\n", $validator->errors()->all()),
                ], 422);
            }
        
            $user = User::findOrFail($id);
            $user->update([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password ? Hash::make($request->password) : $user->password,
            ]);
        
            // Seta as pemissoes no usuário
            $user->syncPermissions(array_keys($request->permissions));

            DB::commit();

            return response()->json([
                'title' => 'Sucesso!',
                'message' => 'Usuário atualizado com sucesso!',
                'type' => 'success'
            ], 201);

        } catch(Exception $exception) {

            DB::rollBack();

            return response()->json([
                'title' => 'Erro na validação',
                'message' => $exception->getMessage(),
                'type' => 'error'
            ], 500);
        }  
    }

    public function destroy($id){
        try {

            DB::beginTransaction();

            $user = User::find($id);
            $user->active = false;
            $user->save();

            DB::commit();

            return response()->json([
                'message' => 'Usuário removido com sucesso!',
                'data' => $user
            ], 201);

        } catch(Exception $exception) {

            DB::rollBack();

            return response()->json([
                'title' => 'Erro na validação',
                'message' => $exception->getMessage(),
                'type' => 'error'
            ], 500);
        }
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{

    protected $fillable = [
        'name',
        'document',
        'observation',
        'time_value',
        'category',
        'chain_of_stores',
    ];
    public static function getAll()
    {
        return self::all();
    }
    public static function getActive()
    {
        return self::query()->where('active', '=', true)->get();

    }
}

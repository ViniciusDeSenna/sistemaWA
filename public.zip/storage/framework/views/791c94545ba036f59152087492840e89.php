<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Diária</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
            margin: 20px;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #696cff;
            font-size: 24px;
            text-transform: uppercase;
        }

        .info {
            margin-bottom: 5px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }

        .info p {
            margin: 5px 0;
            font-size: 10px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
            font-size: 10px;
        }

        th {
            background: #696cff;
            color: white;
            text-transform: uppercase;
        }

        .footer {
            margin-top: 20px;
            text-align: right;
            font-size: 10px;
            color: #555;
        }
    </style>
</head>
<body>
    <h1>Relatório de Diária</h1>

    <?php ($total = 0); ?>

    <?php $__currentLoopData = $dailyRate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collaboratorId => $rates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php ($collaboratorName = $rates[0]['collaborators_name'] ?? 'Não informado'); ?>
        <?php ($collaboratorPixKey = $rates[0]['pix_key']); ?>
        <?php ($totalForCollaborator = 0); ?>
    
        <div class="info">
            <p><strong>Colaborador:</strong> <?php echo e($collaboratorName); ?></p>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Estabelecimento</th>
                        <th>Início</th>
                        <th>Fim</th>
                        <th>Tempo Total</th>
                        <th>Valor a pagar para o colaborador</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php ($totalForCollaborator += $rate->collaborator_participation); ?>
                        <?php ($total += $rate->collaborator_participation); ?>

                        <tr>
                            <td><?php echo e(mb_strimwidth($rate->companies_name ?? 'Não Informado', 0, 20, '...')); ?></td>
                            <td><?php echo e(isset($rate->start) ? Carbon\Carbon::parse($rate->start)->format('d/m/Y H:i:s') : '--/--/-- --:--:--'); ?></td>
                            <td><?php echo e(isset($rate->end) ? Carbon\Carbon::parse($rate->end)->format('d/m/Y H:i:s') : '--/--/-- --:--:--'); ?></td>
                            <td><?php echo e($rate->total_time); ?></td>
                            <td><?php echo e($user->can('Visualizar e inserir informações financeiras nas diárias') ? App\BlueUtils\Money::format($rate->collaborator_participation ?? '0', 'R$ ', 2, ',', '.') : 'R$ --,--'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="footer">
            <p>Total (<?php echo e($collaboratorName); ?>) <?php echo e($user->can('Visualizar e inserir informações financeiras nas diárias') ? App\BlueUtils\Money::format($totalForCollaborator ?? '0', 'R$ ', 2, ',', '.') : 'R$ --,--'); ?> | Pix: <?php echo e($collaboratorPixKey); ?></p>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div class="footer">
        <p>Total <?php echo e($user->can('Visualizar e inserir informações financeiras nas diárias') ? App\BlueUtils\Money::format($total ?? '0', 'R$ ', 2, ',', '.') : 'R$ --,--'); ?></p>
    </div>

    <div class="footer">
        <p>Gerado em: <?php echo e(date('d/m/Y')); ?></p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Vinicius\Documents\GitHub\sistemaWA\resources\views/reports/daily-rate-layout.blade.php ENDPATH**/ ?>
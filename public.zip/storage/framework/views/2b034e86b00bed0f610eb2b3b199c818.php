<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Cadastrando Diária</h5>
            </div> 
            <div class="card-body">
                <form id="form-hourly-rate">

                    <div class="mb-3">
                        <label class="form-label" for="collaborator_id">Colaborador</label>
                        <select class="form-control" id="collaborator_id" name="collaborator_id">
                            <option value="" disabled selected>Selecione um colaborador</option>
                            <?php $__currentLoopData = $collaborators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colaborator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($colaborator->id); ?>" <?php echo e(($dailyRate?->collaborator_id ?? 0) == $colaborator->id ? 'selected' : ''); ?>>
                                    <?php echo e($colaborator->name); ?>

                                </option>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                
                    <div class="mb-3">
                        <label class="form-label" for="company_id">Empresa</label>
                        <select class="form-control" id="company_id" name="company_id">
                            <option value="" disabled selected>Selecione uma empresa</option>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->id); ?>" <?php echo e(($dailyRate?->collaborator_id ?? 0) == $company->id ? 'selected' : ''); ?>>
                                    <?php echo e($company->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                
                    <div class="mb-3">
                        <label class="form-label" for="start">Chegada</label>
                        <input type="datetime-local" class="form-control" id="start" name="start" value="<?php echo e($dailyRate?->start ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="start_interval">Chegada Intervalo</label>
                        <input type="datetime-local" class="form-control" id="start_interval" name="start_interval" value="<?php echo e($dailyRate?->start_interval ?? ''); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label" for="end_interval">Saida Intervalo</label>
                        <input type="datetime-local" class="form-control" id="end_interval" name="end_interval" value="<?php echo e($dailyRate?->end_interval ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="end">Saída</label>
                        <input type="datetime-local" class="form-control" id="end" name="end" value="<?php echo e($dailyRate?->end ?? ''); ?>">
                    </div>
                
                    <div class="mb-3">
                        <label class="form-label" for="daily_total_time">Quantidade de Horas Trabalhadas</label>
                        <input type="text" class="form-control" id="daily_total_time" name="daily_total_time" data-mask="00:00" readonly value="<?php echo e($dailyRate?->daily_total_time ?? ''); ?>">
                    </div>
                
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Visualizar e inserir informações financeiras nas diárias')): ?>
                        <div class="mb-3">
                            <label class="form-label" for="hourly_rate">Valor por Hora</label>
                            <input type="text" class="form-control money" id="hourly_rate" name="hourly_rate" value="<?php echo e($dailyRate?->hourly_rate ?? ''); ?>">
                        </div>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Visualizar e inserir informações financeiras nas diárias')): ?>
                        <div class="mb-3">
                            <label class="form-label" for="costs">Gastos</label>
                            <input type="text" class="form-control money" id="costs" name="costs" value="<?php echo e($dailyRate?->costs ?? ''); ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="costs_description">Descrição dos Gastos</label>
                            <textarea class="form-control" id="costs_description" name="costs_description" rows="4"><?php echo $dailyRate?->costs_description ?? ''; ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="addition">Acréscimos</label>
                            <input type="text" class="form-control money" id="addition" name="addition" value="<?php echo e($dailyRate?->addition ?? ''); ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="addition_description">Descrição dos Acréscimos</label>
                            <textarea class="form-control" id="addition_description" name="addition_description" rows="4"><?php echo $dailyRate?->addition_description ?? ''; ?></textarea>
                        </div>
                    
                        <div class="mb-3">
                            <label class="form-label" for="total">Valor Total</label>
                            <input type="text" class="form-control money" id="total" name="total" readonly value="<?php echo e($dailyRate?->total ?? ''); ?>">
                        </div>
                    <?php endif; ?>
                
                    <div class="mb-3">
                        <label class="form-label" for="pix_key">Chave Pix para pagamento</label>
                        <input type="text" class="form-control" id="pix_key" name="pix_key" value="<?php echo e($dailyRate?->pix_key ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="observation">Observação</label>
                        <textarea class="form-control" id="observation" name="observation" rows="4"><?php echo $dailyRate?->observation ?? ''; ?></textarea>
                    </div>
                </form>
            </div>
            <div class="card-footer d-flex justify-content-end align-items-center">
                <?php if($dailyRate?->id ?? false): ?>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-primary right" style="margin-right: 0%" onclick="update(<?php echo e($dailyRate?->id ?? null); ?>)">Salvar</button>
                    </div>
                <?php else: ?>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-primary right" style="margin-right: 0%"onclick="post()">Salvar</button>
                    </div>
                <?php endif; ?>
            </div> 
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>



<script>
    function post() {
        $.ajax({
            url: '<?php echo e(route('daily-rate.store')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: $('#form-hourly-rate').serialize(),
            success: function(response) {
                Swal.fire({
                    title: response?.title ?? 'Sucesso!',
                    text: response?.message ?? 'Sucesso na ação!',
                    icon: response?.type ?? 'success'
                }).then((result) => {
                    $('#form-hourly-rate')[0].reset();

                    window.location.reload();
                });
            },
            error: function(response) {
                response = JSON.parse(response.responseText);
                Swal.fire({
                    title: response?.title ?? 'Oops!',
                    html: response?.message?.replace(/\n/g, '<br>') ?? 'Erro na ação!',
                    icon: response?.type ?? 'error'
                });
            }
        });
    }

    function update(id) {
        $.ajax({
            url: "<?php echo e(route('daily-rate.update', '')); ?>" + '/' + id,
            type: 'PUT',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: $('#form-hourly-rate').serialize(),
            success: function(response) {
                Swal.fire({
                    title: response?.title ?? 'Sucesso!',
                    text: response?.message ?? 'Sucesso na ação!',
                    icon: response?.type ?? 'success'
                }).then((result) => {
                    $('#form-hourly-rate')[0].reset();

                    window.location.reload();
                });
            },
            error: function(response) {
                response = JSON.parse(response.responseText);
                Swal.fire({
                    title: response?.title ?? 'Oops!',
                    html: response?.message?.replace(/\n/g, '<br>') ?? 'Erro na ação!',
                    icon: response?.type ?? 'error'
                });
            }
        });
    }

    function getHourlyRate() {
        let value = Number($('#hourly_rate').val().replace('.', '').replace(',', '.'));

        if (value === 0) {

            let company = $('#company_id').val();

            if (company === null) {
                return 0;
            }

            $.ajax({
                url: "<?php echo e(route('companies.hourly-rate', '')); ?>" + '/' + company,
                type: 'GET',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    return Number(response);
                },
                error: function(response) {
                    return 0;
                }
            });

        } else {
            return value;
        }
    }

    function difHourly(start, end) {
        try {
            
            let startDate = new Date(start); // Example start datetime
            let endDate = new Date(end);   // Example end datetime

            let diffInMilliseconds = endDate - startDate; // Difference in milliseconds

            // Convert to different units
            let diffInSeconds = diffInMilliseconds / 1000;
            let diffInMinutes = diffInSeconds / 60;
            let diffInHours = diffInMinutes / 60;

            return diffInHours ?? 0;

        } catch {
            return 0;
        }
    }

    function formatTime(value) {
        let hours = Math.floor(value); // Obtém a parte inteira como horas
        let minutes = Math.round((value % 1) * 60); // Converte a parte decimal para minutos

        // Garante que o formato seja sempre HH:MM
        return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
    }

    function calcular() {
        // Pega o valor por hora, se nao existir pega o valor da empresa, insere no calculo e calcula com ela. Se não existir valor é 0
        let hourlyRate = getHourlyRate()

        // pega o horario de inicio até fim e calcula quantas horas deu, faz x valor por hora se nao existir inicio ou fim valor é = 0
        let startDate = $('#form-hourly-rate input[name="start"]').val();
        let endDate = $('#form-hourly-rate input[name="end"]').val();
        let workedHourly = difHourly(startDate, endDate);

        let startIntervalDate = $('#form-hourly-rate input[name="start_interval"]').val();
        let endIntervalDate = $('#form-hourly-rate input[name="end_interval"]').val();
        let intervaledHourly = difHourly(startIntervalDate, endIntervalDate)

        $('#form-hourly-rate input[name="daily_total_time"]').val(formatTime(workedHourly));

        // soma o resto com acrescimos - gastos para descobrir quanto que a impresa vai receber
        let addition = Number($('#form-hourly-rate input[name="addition"]').val().replace('.', '').replace(',', '.'));
        let costs = Number($('#form-hourly-rate input[name="costs"]').val().replace('.', '').replace(',', '.'));

        let total = ((hourlyRate * (workedHourly - intervaledHourly)) + addition) - costs;

        //informa o valor no total
        if (total < 0) {
            return 0;
        }
        $('#form-hourly-rate input[name="total"]').val(total);
    }

    $(document).ready(function () {
        $('#form-hourly-rate').on('input change', function () {
            calcular();
        });

        $('#collaborator_id').select2({
            theme: 'bootstrap-5'
        });
        $('#company_id').select2({
            theme: 'bootstrap-5'
        });

        // Money mask
        $('.money').mask('#.###.###.##0,00', {
            reverse: true,
            translation: {
                '#': {
                pattern: /-?\d/,
                optional: true
                }
            },
            placeholder: "R$ 0,00"
        });
    });

</script><?php /**PATH C:\Users\Vinicius\Documents\GitHub\sistemaWA\resources\views\app\daily-rate\edit.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal5c326df63e67eaf0ded915b08d50f406 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c326df63e67eaf0ded915b08d50f406 = $attributes; } ?>
<?php $component = App\View\Components\ErrorsLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('errors-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ErrorsLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-xxl container-p-y">
        <div class="misc-wrapper">
            <h2 class="mb-2 mx-2">Permissão negada :(</h2>
            <p class="mb-4 mx-2">Oops! 😖 Parece que você não possui permissão para acessar essa página.</p>
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary">Voltar</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c326df63e67eaf0ded915b08d50f406)): ?>
<?php $attributes = $__attributesOriginal5c326df63e67eaf0ded915b08d50f406; ?>
<?php unset($__attributesOriginal5c326df63e67eaf0ded915b08d50f406); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c326df63e67eaf0ded915b08d50f406)): ?>
<?php $component = $__componentOriginal5c326df63e67eaf0ded915b08d50f406; ?>
<?php unset($__componentOriginal5c326df63e67eaf0ded915b08d50f406); ?>
<?php endif; ?><?php /**PATH C:\Users\Vinicius\Documents\GitHub\sistemaWA\resources\views\errors\403.blade.php ENDPATH**/ ?>
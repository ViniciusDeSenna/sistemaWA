<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Cadastrando Diária</h5>
            </div> 
            <div class="card-body">
                <form id="form-hourly-rate">

                    <div class="mb-3">
                        <label class="form-label" for="collaborator_id">Colaborador</label>
                        <select class="form-control" id="collaborator_id" name="collaborator_id">
                            <option value="" disabled selected>Selecione um colaborador</option>
                            <?php $__currentLoopData = $collaborators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colaborator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($colaborator->id); ?>" <?php echo e(($dailyRate?->collaborator_id ?? 0) == $colaborator->id ? 'selected' : ''); ?>>
                                    <?php echo e($colaborator->name); ?>

                                </option>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                
                    <div class="mb-3">
                        <label class="form-label" for="company_id">Empresa</label>
                        <select class="form-control" id="company_id" name="company_id">
                            <option value="" disabled selected>Selecione uma empresa</option>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->id); ?>" <?php echo e(($dailyRate?->collaborator_id ?? 0) == $company->id ? 'selected' : ''); ?>>
                                    <?php echo e($company->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                
                    <div class="mb-3">
                        <label class="form-label" for="start">Chegada</label>
                        <input type="datetime-local" class="form-control" id="start" name="start" value="<?php echo e($dailyRate?->start ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="end">Saída</label>
                        <input type="datetime-local" class="form-control" id="end" name="end" value="<?php echo e($dailyRate?->end ?? ''); ?>">
                    </div>
                
                    <div class="mb-3">
                        <label class="form-label" for="total_time">Quantidade de Horas Trabalhadas</label>
                        <input type="text" class="form-control" id="total_time" name="total_time" data-mask="00:00" readonly value="<?php echo e($dailyRate?->total_time ?? ''); ?>">
                    </div>
                
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Visualizar e inserir informações financeiras nas diárias')): ?>
                        <div class="mb-3">
                            <label class="form-label" for="hourly_rate">Valor por Hora</label>
                            <input type="text" class="form-control money" id="hourly_rate" name="hourly_rate" value="<?php echo e($dailyRate?->hourly_rate ?? ''); ?>">
                        </div>
                 
                        <div class="mb-3">
                            <label class="form-label" for="costs">Gastos</label>
                            <input type="text" class="form-control money" id="costs" name="costs" value="<?php echo e(number_format($dailyRate?->costs ?? '0', 2, ".", ",")); ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="costs_description">Descrição dos Gastos</label>
                            <textarea class="form-control" id="costs_description" name="costs_description" rows="4"><?php echo $dailyRate?->costs_description ?? ''; ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="addition">Acréscimos</label>
                            <input type="text" class="form-control money" id="addition" name="addition" value="<?php echo e(number_format($dailyRate?->addition ?? '0', 2, ".", ",")); ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="addition_description">Descrição dos Acréscimos</label>
                            <textarea class="form-control" id="addition_description" name="addition_description" rows="4"><?php echo $dailyRate?->addition_description ?? ''; ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="addition">Participação do Colaborador</label>
                            <input type="text" class="form-control money" id="collaborator_participation" name="collaborator_participation" value="<?php echo e(number_format($dailyRate?->collaborator_participation ?? '0', 2, ".", ",")); ?>">
                        </div>
                    
                        <div class="mb-3">
                            <label class="form-label" for="total">Valor Total</label>
                            <input type="text" class="form-control money" id="total" name="total" readonly value="<?php echo e(number_format($dailyRate?->total ?? '0', 2, ".", ",")); ?>">
                        </div>
                    <?php endif; ?>
                
                    

                    <div class="mb-3">
                        <label class="form-label" for="observation">Observação</label>
                        <textarea class="form-control" id="observation" name="observation" rows="4"><?php echo $dailyRate?->observation ?? ''; ?></textarea>
                    </div>
                </form>
            </div>
            <div class="card-footer d-flex justify-content-end align-items-center">
                <?php if($dailyRate?->id ?? false): ?>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-primary right" style="margin-right: 0%" onclick="update(<?php echo e($dailyRate?->id ?? null); ?>)">Salvar</button>
                    </div>
                <?php else: ?>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-primary right" style="margin-right: 0%"onclick="post()">Salvar</button>
                    </div>
                <?php endif; ?>
            </div> 
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>



<script>
    function post() {
        $.ajax({
            url: '<?php echo e(route('daily-rate.store')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: $('#form-hourly-rate').serialize(),
            success: function(response) {
                Swal.fire({
                    title: response?.title ?? 'Sucesso!',
                    text: response?.message ?? 'Sucesso na ação!',
                    icon: response?.type ?? 'success'
                }).then((result) => {
                    $('#form-hourly-rate')[0].reset();

                    window.location.reload();
                });
            },
            error: function(response) {
                response = JSON.parse(response.responseText);
                Swal.fire({
                    title: response?.title ?? 'Oops!',
                    html: response?.message?.replace(/\n/g, '<br>') ?? 'Erro na ação!',
                    icon: response?.type ?? 'error'
                });
            }
        });
    }

    function update(id) {
        $.ajax({
            url: "<?php echo e(route('daily-rate.update', '')); ?>" + '/' + id,
            type: 'PUT',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: $('#form-hourly-rate').serialize(),
            success: function(response) {
                Swal.fire({
                    title: response?.title ?? 'Sucesso!',
                    text: response?.message ?? 'Sucesso na ação!',
                    icon: response?.type ?? 'success'
                }).then((result) => {
                    $('#form-hourly-rate')[0].reset();

                    window.location.reload();
                });
            },
            error: function(response) {
                response = JSON.parse(response.responseText);
                Swal.fire({
                    title: response?.title ?? 'Oops!',
                    html: response?.message?.replace(/\n/g, '<br>') ?? 'Erro na ação!',
                    icon: response?.type ?? 'error'
                });
            }
        });
    }

    function getHourlyRate(callback) {
        try {
            let value = $('#hourly_rate').val();

            if (value === "") {
                let company = $('#company_id').val();

                if (company === null) {
                    callback(0);
                    return;
                }

                $.ajax({
                    url: "<?php echo e(route('companies.hourly-rate', '')); ?>" + '/' + company,
                    type: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        $('#hourly_rate').val(response.replace('.', ','));
                        callback(Number(response.replace(',', '.')));
                    },
                    error: function() {
                        callback(0);
                    }
                });

            } else {
                callback(Number(value.replace(',', '.')));
            }
        } catch {
            callback(0);
        }
    }

    function getPixKey() {
        let value = $('#pix_key').val();
        if (value === "") {
            let collaborator = $('#collaborator_id').val();

            $.ajax({
                url: "<?php echo e(route('collaborators.pix-key', '')); ?>" + '/' + collaborator,
                type: 'GET',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    $('#pix_key').val(response)
                },
            });
        }
    }

    function difHourly(start, end) {
        try {

            if (start == "") return 0;
            if (end == "") return 0;
            
            let startDate = new Date(start); // Example start datetime
            let endDate = new Date(end);   // Example end datetime

            let diffInMilliseconds = endDate - startDate; // Difference in milliseconds

            // Convert to different units
            let diffInSeconds = diffInMilliseconds / 1000;
            let diffInMinutes = diffInSeconds / 60;
            let diffInHours = diffInMinutes / 60;

            return diffInHours ?? 0;

        } catch {
            return 0;
        }
    }

    function formatTime(value) {
        let hours = Math.floor(value); // Obtém a parte inteira como horas
        let minutes = Math.round((value % 1) * 60); // Converte a parte decimal para minutos

        // Garante que o formato seja sempre HH:MM
        return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
    }

    function calcular() {
        // Chama getHourlyRate com um callback para lidar com o valor retornado
        getHourlyRate(function(hourlyRate) {

            // Pega o horário de início até fim e calcula quantas horas deu, faz x valor por hora se não existir início ou fim valor é = 0
            let startDate = $('#form-hourly-rate input[name="start"]').val();
            let endDate = $('#form-hourly-rate input[name="end"]').val();
            let workedHourly = difHourly(startDate, endDate);

            $('#form-hourly-rate input[name="total_time"]').val(formatTime(workedHourly));

            // Soma o resto com acréscimos - gastos para descobrir quanto a empresa vai receber
            let addition = Number($('#form-hourly-rate input[name="addition"]').val().replace('.', '').replace(',', '.'));
            let costs = Number($('#form-hourly-rate input[name="costs"]').val().replace('.', '').replace(',', '.'));
            let collaboratorParticipation = Number($('#form-hourly-rate input[name="collaborator_participation"]').val().replace('.', '').replace(',', '.'));

            console.log(hourlyRate);
            console.log(workedHourly);
            console.log(addition);
            console.log(costs);
            console.log(collaboratorParticipation);

            // Calcula o total
            let total = (((hourlyRate * workedHourly) + addition) - costs) - collaboratorParticipation;

            // Aqui você pode adicionar o valor no campo de total, se necessário
            $('#form-hourly-rate input[name="total"]').val(total.replace(',', '.'));
        });
    }


    $(document).ready(function () {
        $('#form-hourly-rate').on('input change', function () {
            calcular();
        });

        // $('#collaborator_id').on('change', function () { 
        //     console.log('Colaborador selecionado:', $(this).val());
        //     getPixKey();
        // });


        $('#collaborator_id').select2({
            theme: 'bootstrap-5'
        });
        $('#company_id').select2({
            theme: 'bootstrap-5'
        });

        $('.money').mask('#.###.###.##0,00', {
            reverse: true,
            translation: {
                '#': {
                pattern: /-?\d/,
                optional: true
                }
            },
            placeholder: "R$ 0,00"
        });

        // getPixKey();
    });

</script><?php /**PATH C:\Users\Vinicius\Documents\GitHub\sistemaWA\resources\views/app/daily-rate/edit.blade.php ENDPATH**/ ?>